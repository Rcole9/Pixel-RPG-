# Runes of the Void - Pixel RPG

An isometric pixel RPG built with Godot 4.3

## Game Features
- 3 unique character classes (Tank, Healer, DPS)
- Real-time combat system
- Dynamic loot generation system
- Multiple zones and dungeons
- Boss encounters

## Playing the Game

### Live Version
[Play Online via Web Interface](https://upgraded-chainsaw-7v6gg457x4q6hrq7q-6080.app.github.dev/vnc.html)

### Local Development
1. Install Godot 4.3
2. Open the project with Godot
3. Click "Play" or press F5

### Building

#### Desktop Export
```bash
godot --export-release "Linux/X11" build/linux/game
godot --export-release "Windows Desktop" build/windows/game.exe
godot --export-release "macOS" build/macos/game.dmg
```

#### HTML5 Export
```bash
godot --export-release "Web" build/web/index.html
```

## Project Structure
```
├── scenes/          # Game scenes (levels, UI, entities)
├── scripts/         # GDScript source code
├── build/           # Build outputs
└── project.godot    # Godot project configuration
```

## System Requirements
- Godot 4.3+
- 4GB RAM
- Modern web browser (for web version)

---
Built with ❤️ using Godot Engine
