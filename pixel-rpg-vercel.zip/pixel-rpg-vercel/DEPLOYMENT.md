# Deployment Guide for Runes of the Void

## Option 1: Deploy to Vercel (Recommended)

### Prerequisites
- GitHub account
- Vercel account

### Steps

1. **Push to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git push -u origin main
   ```

2. **Deploy to Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Click "New Project"
   - Import your GitHub repository
   - Click "Deploy"

Your game will be live at `https://yourproject.vercel.app`

## Option 2: Run Locally

### Prerequisites
- Node.js 14+
- npm

### Steps

```bash
npm install
npm start
```

Open `http://localhost:3000` in your browser.

## Option 3: Docker Deployment

Create `Dockerfile`:
```dockerfile
FROM node:18-slim
WORKDIR /app
COPY package.json .
RUN npm install
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
```

Build and run:
```bash
docker build -t pixel-rpg .
docker run -p 3000:3000 pixel-rpg
```

## Option 4: Full Game Build with Godot

To create a complete HTML5 export:

1. Install Godot 4.3
2. Download export templates for Web
3. Open the project in Godot
4. Go to Project > Export
5. Create new "Web" preset
6. Click "Export Project"

This will generate a full WebAssembly version that runs natively in the browser (no streaming required).

---

**Note:** The current deployment includes a landing page that links to the live game stream. For a true native web build, follow Option 4 above.
