# Quick Start - Vercel Deployment

## 🚀 Deploy in 3 Steps

### Step 1: Push to GitHub
```bash
cd pixel-rpg-vercel
git init
git add .
git commit -m "Deploy Pixel RPG to Vercel"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/pixel-rpg.git
git push -u origin main
```

### Step 2: Go to Vercel
1. Visit https://vercel.com
2. Click "Add New..." → "Project"
3. Select "Import Git Repository"
4. Paste your GitHub repo URL
5. Click "Import"

### Step 3: Deploy!
Vercel will automatically:
- Build your project
- Deploy to a live URL
- Set up continuous deployment on git push

**Your game will be live in ~60 seconds!**

---

## 📱 Access Your Game

After deployment, visit:
```
https://YOUR_PROJECT_NAME.vercel.app
```

Your visitors will see:
- ✅ Game title and description
- ✅ Direct link to play the live game
- ✅ Game information and controls

---

## 🎮 Play Links

### Live Game (Current)
- **Web VNC Stream:** https://upgraded-chainsaw-7v6gg457x4q6hrq7q-6080.app.github.dev/vnc.html

### After Vercel Deployment
- **Vercel Site:** https://YOUR_PROJECT_NAME.vercel.app (redirects to live stream)

---

## 🐳 Alternative: Deploy with Docker

### Using Docker Hub:
```bash
docker build -t pixel-rpg .
docker run -p 3000:3000 pixel-rpg
```

Open http://localhost:3000

### Deploy to Cloud Run, Railway, or Render:
All support Docker containers and offer free tiers.

---

## 💡 What's Happening?

**Current Setup:**
- `index.html` - Landing page with game info
- Linked to live Godot game stream (WebSocket via noVNC)
- No server required - pure static hosting on Vercel

**Full HTML5 Build (Optional):**
- For true browser-native game (no streaming)
- Requires Godot HTML5 export templates
- Contact support if you need this version

---

## ✅ Vercel Deployment Features

You get:
- ✅ Global CDN
- ✅ SSL/HTTPS automatic
- ✅ Custom domain support
- ✅ Automatic deployments on git push
- ✅ Free tier with no limits
- ✅ Analytics and monitoring

---

**Need Help?** Visit vercel.com/docs or email support@vercel.com
